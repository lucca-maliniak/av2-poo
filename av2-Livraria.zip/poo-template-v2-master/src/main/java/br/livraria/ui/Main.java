package br.livraria.ui;

import br.livraria.dominio.Livro;
import br.livraria.dominio.Editora;
import jakarta.persistence.Persistence;

public class Main {
    public static void main(String[] args) {
        var factory = Persistence.createEntityManagerFactory("livrariaav2");
        var em = factory.createEntityManager();

        Editora editoraA = new Editora("Editora 1", "321321321");
        Livro livroA = new Livro("Livro 1", "Lucca", 2023, 25.50);

        em.getTransaction().begin();
        em.persist(livroA); // insert
        em.getTransaction().commit();

        em.getTransaction().begin();
        em.persist(editoraA); // insert
        em.getTransaction().commit();

        var livro = em.find(Livro.class, 2); // select
        System.out.println("*********************************");
        System.out.println("Livro 1: " + livro);

        livro.setTitulo("Titulo Diferente do primeiro");

        em.getTransaction().begin();
        em.merge(livro); // update
        em.getTransaction().commit();

        System.out.println("*********************************");
        System.out.println("Livro após alteração: " + livro);

        em.getTransaction().begin();
        em.remove(livro); // remove
        em.getTransaction().commit();

        em.close();
        factory.close();
    }
}
