package br.livraria.dominio;

import jakarta.persistence.*;
import java.util.Objects;

@Entity
@Table (name = "tbl_livro")
public class Livro {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    @Column (name = "livro_id")
    private Integer id;

    @Column (name = "titulo_livro")
    private String titulo;
    @Column (name = "autor_livro")
    private String autor;
    @Column (name = "dt_livro")
    private Integer anoPublicacao;
    @Column (name = "preco_livro")
    private Double preco;

    public Livro() {}

    public Livro(String titulo, String autor, Integer dataAno, Double preco){
        this.titulo = titulo;
        this.autor = autor;
        this.anoPublicacao = dataAno;
        this.preco = preco;
    }

    @Override
    public String toString() {
        return "Livro{" +
                "id=" + id +
                ", titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", anoPublicacao=" + anoPublicacao +
                ", preco=" + preco +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Livro livro = (Livro) o;
        return Objects.equals(id, livro.id) && Objects.equals(titulo, livro.titulo) && Objects.equals(autor, livro.autor) && Objects.equals(anoPublicacao, livro.anoPublicacao) && Objects.equals(preco, livro.preco);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, titulo, autor, anoPublicacao, preco);
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public Integer getAnoPublicacao() {
        return anoPublicacao;
    }

    public void setAnoPublicacao(Integer anoPublicacao) {
        this.anoPublicacao = anoPublicacao;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }
}
